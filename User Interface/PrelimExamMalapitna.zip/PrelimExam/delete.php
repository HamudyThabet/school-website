<?php
include 'db.php';
?>