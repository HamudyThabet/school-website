<?php 
include "db.php";
$sql = "SELECT * FROM courses";
$result = $conn->query($sql);

include "head.php"; 
?>
<section class="hero" style ="background: url('https://i.ytimg.com/vi/_Ud8nnIVoEw/hq720.jpg?sqp=-oaymwEhCK4FEIIDSFryq4qpAxMIARUAAAAAGAElAADIQj0AgKJD&rs=AOn4CLAXVtnXrXAOhr7IgodtsW1PB3CHrA') center center / cover no-repeat;">
  <div class="overlay"></div>
  <h1>Welcome to Greenfield Institute of Technology</h1>
</section>
<section id="courses">
  <div class="container">
    <div class="section-title">
      <h2>Courses Offered</h2>
    </div>
    <table border="1">
      <tr>
        <th>Course ID</th>
        <th>Course Name</th>
        <th>Course Description</th>
      </tr>
      <?php while ($row = $result->fetch_assoc()) { ?>
      <tr>
        <td><?= $row['id'] ?></td>
        <td><?= $row['course_name'] ?></td>
        <td><?= $row['description'] ?></td>
      </tr>
      <?php } ?>
    </table>
  </div>
</section>
<?php include "foot.php"; ?>
