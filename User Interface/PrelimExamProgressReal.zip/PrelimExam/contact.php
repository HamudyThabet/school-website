<?php
include "head.php";
?>
<section class="hero" style ="background: url('https://i.ytimg.com/vi/_Ud8nnIVoEw/hq720.jpg?sqp=-oaymwEhCK4FEIIDSFryq4qpAxMIARUAAAAAGAElAADIQj0AgKJD&rs=AOn4CLAXVtnXrXAOhr7IgodtsW1PB3CHrA') center center / cover no-repeat;">
  <div class="overlay"></div>
  <h1>Welcome to Greenfield Institute of Technology</h1>
</section>
<h2>Contact Us</h2>
<form method="post">
  <label>Name</label><input name="name" required>
  <label>Email</label><input type="email" name="email" required>
  <label>Message</label><textarea name="message"></textarea>
  <button type="submit">Send</button>
</form>
<?php include "foot.php"; ?>
