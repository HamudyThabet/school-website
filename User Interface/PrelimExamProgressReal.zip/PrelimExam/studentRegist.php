<?php
require "db.php";

$sql = "SELECT * FROM students";
$result = $conn->query($sql);

include "head.php";
?>
<section class="hero" style ="background: url('https://i.ytimg.com/vi/_Ud8nnIVoEw/hq720.jpg?sqp=-oaymwEhCK4FEIIDSFryq4qpAxMIARUAAAAAGAElAADIQj0AgKJD&rs=AOn4CLAXVtnXrXAOhr7IgodtsW1PB3CHrA') center center / cover no-repeat;">
  <div class="overlay"></div>
  <h1>Welcome to Greenfield Institute of Technology</h1>
</section>
<h2>Student List</h2>
<table border="1">
  <tr>
    <th>ID</th>
    <th>Name</th>
    <th>Age</th>
    <th>Course ID</th>
    <th>Year Level</th>
  </tr>
  <?php while ($row = $result->fetch_assoc()) { ?>
  <tr>
    <td><?= $row['id'] ?></td>
    <td><?= $row['name'] ?></td>
    <td><?= $row['age'] ?></td>
    <td><?= $row['course_id'] ?></td>
    <td><?= $row['year_level'] ?></td>
  </tr>
  <?php } ?>
</table>
<?php include "foot.php"; ?>
