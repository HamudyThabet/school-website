<?php
require "db.php";
$success = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $stmt = $pdo->prepare("INSERT INTO messages (name, email, message) VALUES (?,?,?)");
    $stmt->execute([$_POST['name'], $_POST['email'], $_POST['message']]);
    $success = "Thank you! Message sent.";
}
include "head.php";
?>
<h2>Contact Us</h2>
<?php if ($success): ?><p style="color:green"><?= $success ?></p><?php endif; ?>
<form method="post">
  <label>Name</label><input name="name" required>
  <label>Email</label><input type="email" name="email" required>
  <label>Message</label><textarea name="message"></textarea>
  <button type="submit">Send</button>
</form>
<?php include "foot.php"; ?>
