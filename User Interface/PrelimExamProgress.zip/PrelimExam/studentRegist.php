<?php
require "db.php";
$msg = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $stmt = $pdo->prepare("INSERT INTO students (student_id, first_name, last_name, age, year_level) VALUES (?,?,?,?,?)");
    $stmt->execute([$_POST['student_id'], $_POST['first_name'], $_POST['last_name'], $_POST['age'], $_POST['year_level']]);
    $msg = "Student registered successfully!";
}
include "head.php";
?>
<h2>Student Registration</h2>
<?php if ($msg): ?><p style="color:green"><?= $msg ?></p><?php endif; ?>
<form method="post">
  <label>Student ID</label><input name="student_id" required>
  <label>First Name</label><input name="first_name" required>
  <label>Last Name</label><input name="last_name" required>
  <label>Age</label><input type="number" name="age">
  <label>Year Level</label>
  <select name="year_level"><option>1</option><option>2</option><option>3</option><option>4</option></select>
  <button type="submit">Register</button>
</form>
<?php include "foot.php"; ?>
