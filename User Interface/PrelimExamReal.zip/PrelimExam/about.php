<?php include "head.php"; ?>
<h2>About Us</h2>
<p><strong>History:</strong> Greenfield Institute of Technology was founded in 2001...</p>
<p><strong>Vision:</strong> To be a leading institution in IT and business education.</p>
<p><strong>Mission:</strong> Develop competent and ethical professionals.</p>
<p><strong>Core Values:</strong> Integrity, Innovation, Excellence.</p>
<?php include "foot.php"; ?>
