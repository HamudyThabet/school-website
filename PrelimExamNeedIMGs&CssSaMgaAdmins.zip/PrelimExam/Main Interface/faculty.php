<?php include "head.php"; ?>
<h2>Faculty</h2>
<ul>
  <li>Prof. Maria Santos – Computer Science – maria@git.edu</li>
  <li>Prof. Juan Reyes – Information Technology – juan@git.edu</li>
</ul>
<?php include "foot.php"; ?>
