<?php
session_start();

// Check if logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

require_once "db.php";

// Optional: Fetch user info for display
$username = $_SESSION['username'] ?? 'Admin';
$sql = "SELECT username FROM users WHERE id = " . intval($_SESSION['user_id']);
$result = $conn->query($sql);
if ($result && $result->num_rows === 1) {
    $user = $result->fetch_assoc();
    $username = $user['username'];
}

include "../admin_header.php";
?>
<section class="hero" style ="background: linear-gradient(rgba(0, 0, 0, 0.2), rgba(0, 0, 0, 0.5)), url('https://www.shutterstock.com/image-photo/blurred-background-vibrant-modern-university-600nw-2550498515.jpg') center center / cover no-repeat;">
  <div class="overlay"></div>
  <h2>Welcome to Admin Dashboard, <?= htmlspecialchars($username) ?>!</h2>
  <br><p>You are logged in successfully.</p>
</section>
    
    

<?php include "../admin_footer.php"; ?>